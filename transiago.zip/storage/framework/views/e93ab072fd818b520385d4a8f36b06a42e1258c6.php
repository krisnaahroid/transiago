<?php $__env->startSection('title', '| Create'); ?>

<?php $__env->startSection('stylesheets'); ?>
    <?php echo Html::style('css/parsley.css'); ?>

    <?php echo Html::style('css/select2.min.css'); ?>

    <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>

    <script>
        tinymce.init({
          selector:'textarea',
          plugins: "textcolor colorpicker image lists table link",
          toolbar: "forecolor backcolor image numlist bullist table link",
          image_caption: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <?php echo $__env->make('inc._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>
                <div class="panel-body">
                    <div class="row">
                      <div class="col-md-10 col-md-offset-1">
                        <h2>Create new Service</h2>
                        <hr>
                        <?php echo Form::open(array('route' => 'post.service.post', 'data-parsley-validate' => '', 'files' => true)); ?>

                          <?php echo e(Form::label('title', 'Title')); ?>

                          <?php echo e(Form::text('title', null, array('class' => 'form-control', 'required' => '', 'maxlength' => '225'))); ?>

                            <br>
                          <?php echo e(Form::label('slug', 'Slug' )); ?>

                          <?php echo e(Form::text('slug', null, array('class' => 'form-control', 'required' => '', 'minlength' => '5', 'maxlength' => '255'))); ?>


                            <br>

                            <?php echo e(Form::label('upload_img', 'Upload Image')); ?>

                            <?php echo e(Form::file('upload_img')); ?>

                            <br>

                          <?php echo e(Form::label('body', "Post Body:")); ?>

                          <?php echo e(Form::textarea('body', null, array('class' => 'form-control', 'required' => ''))); ?>

                            <br>
                          <?php echo e(Form::submit('Create Post', array('class' => 'btn btn-secondary btn-lg btn-block'))); ?>

                        <?php echo Form::close(); ?>

                      </div>
                    </div>
                    <br>
                    <br>
                    <br>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo Html::script('js/parsley.min.js'); ?>

    <?php echo Html::script('js/select2.min.js'); ?>



    <script type="text/javascript">
      $('.select2-multi').select2();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>