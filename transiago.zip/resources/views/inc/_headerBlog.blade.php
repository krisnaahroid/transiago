<div class="wrapper header-blog">
    <div class="wp-content-width">
            <div class="navtop">
                    <div class="logo">
                        <a href="/"><img src="/img/logo.png"  alt="transiago logo penerjemah"></a>
                        <strong>Transiago | Translation</strong>
                    </div>
            </div>
    </div>

<div class="wrapper">
    <div class="wp-content-width">
        <div class="section-container-general general-info">
            <div class="grid-column-general general-info-left slogan">
                <h1>Transiago| Blog</h1>
                    <h2>Science of my life and make it better.</h2>
                        <br>
                     <p>Lorem ipsum dolor,  Blanditiis distinctio vitae repellendus necessitatibus in cupiditate sit nam libero iusto ipsa ut quisquam eligendi, eos voluptatum quos doloremque minus! Doloremque, natus?</p>
                <a href="#" class="btn-primary btn-become">Become a Translator</a>
            </div>
            <div class="grid-column-general general-info-right image-blog">
                <picture>
                        <img src="/img/blog-icon-transiago.png" width="500px" alt="penerjemah transiago translation">
                </picture>
            </div>
        </div>
    </div>
</div>
</div>

<div class="navmenu">
<div class="nav-blog">
    <div class="nav-link">
      <a href="{{ route('home') }}">Home</a>
    </div>
    <div class="nav-link">
      <a href="#">iNew</a>
    </div>
    <div class="nav-link">
      <a href="#">Tutorial</a>
    </div>
    <div class="nav-link">
      <a href="#">About Us</a>
    </div>
</div>
</div>
