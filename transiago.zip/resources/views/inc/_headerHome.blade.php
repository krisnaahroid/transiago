<div class="wrapper header">
    <div class="wp-content-width">
            <div class="navtop">
                    <div class="logo">
                        <a href="{{ route('home') }}"><img src="/img/logo.png"  alt="logo transiago penerjemah tersumpah"></a>
                        <strong>Transiago | Translation</strong>
                    </div>
                    <div class="menutop">
                        <ul>
                            <li><a href="{{route('home')}}">Home</a></li>
                            <li><a href="#">Service</a></li>
                            <li><a href="{{route('blog.index')}}">Blog</a></li>
                            <li><a href="#">Contact</a></li>
                            <li><a href="#">Login</a></li>
                            <li><a href="#" class="sign-up">Sign Up</a></li>
                        </ul>

                    </div>
            </div>
    </div>

<div class="wrapper">
    <div class="wp-content-width">
        <div class="section-container-general general-info">
            <div class="grid-column-general general-info-left slogan">
                <h1>Transiago Translation</h1>
                    <h3>Build you're dream with us and make it better</h3>
                        <br>
                     <p>Lorem ipsum dolor,  Blanditiis distinctio vitae repellendus necessitatibus in cupiditate sit nam libero iusto ipsa ut quisquam eligendi, eos voluptatum quos doloremque minus! Doloremque, natus?</p>
                <a href="#" class="btn-primary btn-become">Become a Translator</a>
            </div>
            <div class="grid-column-general general-info-right">
                <picture>
                        <img src="/img/market-transiago-penerjemah.png" width="520px" alt="">
                </picture>
            </div>
        </div>
    </div>
</div>
</div>
